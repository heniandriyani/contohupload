<html>

<head>
    <title> BUKU TAMU </title>
</head>

<body background="smk.jpg">
    <h1>
        <color="black">
            <?php
            echo 'Selamat Datang ' . $_SESSION['nama'];
            ?>
    </h1>
    <h1>
        <color="black">Apa Kabarmu Hari Ini?
    </h1>
</body>
<!-- Page Heading -->
          

                    <!-- Content Row -->
</html>