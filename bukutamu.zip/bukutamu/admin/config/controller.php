<?php

// function fungsi menampilkan data
function select($query)
{
    // koneksi database 
    global $db;

    $result = mysqli_query($db, $query);
    $rows = [];

    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }

    return $rows;
}

// fungsi menambah data pengunjung
function create_pengunjung($post)
{
    global $db;

    $nama = $post['nama'];
    $nomor = $post['nomor'];
    $kantor = $post['kantor'];
    $alamat = $post['alamat'];
    $keperluan = $post['keperluan'];
    $kesan = $post['kesan'];



    // query tambah data
    $query = "INSERT INTO  pengunjung VALUES(null, '$nama', '$nomor', '$kantor', '$alamat', '$keperluan', '$kesan', CURRENT_TIMESTAMP())";

    mysqli_query($db, $query);

    return mysqli_affected_rows($db);
}

// fungsi mengubah data barang
function update_pengunjung($post)
{
    global $db;

    $id_pengunjung = $post['id_pengunjung'];

    $nama = $post['nama'];
    $nomor = $post['nomor'];
    $kantor = $post['kantor'];
    $alamat = $post['alamat'];
    $keperluan = $post['keperluan'];
    $kesan = $post['kesan'];


    // query Ubah data
    $query = "UPDATE pengunjung SET
    nama         = '$nama',
    nomor        = '$nomor',
    kantor       = '$kantor',
    alamat       = '$alamat',
    keperluan    = '$keperluan',
    kesan        = '$kesan' WHERE id_pengunjung = $id_pengunjung ";

    mysqli_query($db, $query);

    return mysqli_affected_rows($db);
}

// fungsi hapus data pengunjung
function delete_pengunjung($id_pengunjung)
{
    global $db;

    // query hapus data pengunjung
    $query = "DELETE FROM pengunjung WHERE id_pengunjung = $id_pengunjung";

    mysqli_query($db, $query);

    return mysqli_affected_rows($db);

}

// fungsi upload file / foto
// function upload_file()
// {
//     $namaFile = $_FILES['foto']['name'];
//     $ukuranFile = $_FILES['foto']['size'];
//     $error = $_FILES['foto']['error'];
//     $tmpName = $_FILES['foto']['tmp_name'];

    // check file upload
//     $extensifileValid = ['jpg', 'jpeg', 'png'];
//     $extensifile = explode('.', $namaFile);
//     $extensifile = strtolower(end($extensifile));

    // check format
//     if (!in_array($extensifile, $extensifileValid)) {
        // pesan gagal
//         echo "<script>
//             alert('Format File Tidak Valid');
//             document.location.href = 'tambah-pengunjung.php';
//         </script>";
//         die();
//     }

    // check ukuran file
//     if ($ukuranFile > 5048000) {
        // pesan gagal
//         echo "<script>
//             alert('Ukuran file Max 5 MB');
//             document.location.href = 'tambah-pengunjung.php';
//         </script>";
//         die();
//     }

    // generate nama file baru
//     $namaFileBaru = uniqid();
//     $namaFileBaru .= '.';
//     $namaFileBaru .= $extensifile;

    // pindah ke local folder
//     move_uploaded_file($tmpName, 'assets/img' . $namaFileBaru);
//     return $namaFileBaru;
// }