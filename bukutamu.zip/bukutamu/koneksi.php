<?php

$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'buku_tamu';

$koneksi = mysqli_connect($host, $user, $pass, $db) or die('koneksi gagal!');
